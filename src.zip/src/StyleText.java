
public class StyleText extends Token{

	public StyleText(String text) {
		super(text);
		
	}

}
