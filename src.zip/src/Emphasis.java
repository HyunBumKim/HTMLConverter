
public class Emphasis {

}
