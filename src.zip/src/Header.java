
public class Header extends Node {

	public int level;
	public Header(String text) {
		super(text);
	}
	


}
