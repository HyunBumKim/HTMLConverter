
public class PlainText {

}
