
public class Link {

}
