
public class Horizonta extends Node {

	public Horizonta(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
