
interface MDElement {
	public  void accept(MDElementVisitor v);

}
