
public class CodeBlock extends Node{

	public CodeBlock(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
