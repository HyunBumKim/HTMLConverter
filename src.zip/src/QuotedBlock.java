
public class QuotedBlock extends Node{

	public QuotedBlock(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

}
